import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Mazallat from "./Mazallat";

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/mazallat" element={<Mazallat />} />
        <Route
          path="*"
          element={
            <div dir="rtl" className="font-sans bg-[#fafafa] text-[#302a23]">
              {/* أيقونات جانبية عائمة للتواصل */}
              <aside className="fixed top-1/3 md:left-4 left-1 z-50 flex flex-col gap-2 items-center">
                <a
                  href="tel:+966553719009"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-[#51ac41] hover:bg-[#39383d] rounded-full p-2 shadow transition"
                  title="اتصال مباشر"
                >
                  <img
                    src="https://img.icons8.com/fluency/48/000000/phone.png"
                    alt="اتصال"
                    className="w-9 h-9"
                  />
                </a>
                <a
                  href="https://wa.me/+966553719009"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-[#51ac41] rounded-full p-2 shadow hover:bg-[#b8975d] transition"
                  title="واتساب"
                >
                  <img
                    src="https://img.icons8.com/color/48/000000/whatsapp--v1.png"
                    alt="واتساب"
                    className="w-9 h-9"
                  />
                </a>
                <a
                  href="https://www.instagram.com/aldiyarglobal/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-[#fff] rounded-full p-2 shadow hover:bg-[#b8975d] transition"
                  title="انستجرام"
                >
                  <img
                    src="https://img.icons8.com/color/48/000000/instagram-new--v1.png"
                    alt="انستجرام"
                    className="w-9 h-9"
                  />
                </a>
              </aside>
              {/* زر واتساب عائم دائم بأسفل الشاشة */}
              <a
                href="https://wa.me/+966553719009"
                target="_blank"
                rel="noopener noreferrer"
                className="fixed z-50 bottom-5 right-5 bg-green-500 hover:bg-[#51ac41] text-white rounded-full p-4 shadow-lg animate-pop-in border-4 border-white"
                style={{ boxShadow: "0 4px 16px 0 #51ac4180" }}
                aria-label="واتساب سريع"
              >
                <img
                  src="https://img.icons8.com/color/48/000000/whatsapp--v1.png"
                  alt="واتساب"
                  className="w-8 h-8"
                />
              </a>
              {/* شريط الهيدر العلوي */}
              <div className="bg-[#39383d] text-[#f9f9f8] text-sm py-2 px-4 flex justify-between items-center">
                <div className="flex gap-5 items-center">
                  <span className="font-semibold">0553719009</span>
                  <span className="hidden md:inline">info@aldiyarglobal.com</span>
                </div>
                <div className="flex gap-3 items-center">
                  <a
                    href="https://wa.me/+966553719009"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <img
                      src="https://img.icons8.com/color/32/000000/whatsapp--v1.png"
                      alt="واتساب"
                      className="w-5 h-5"
                    />
                  </a>
                  <a
                    href="https://www.instagram.com/aldiyarglobal/"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <img
                      src="https://img.icons8.com/color/32/000000/instagram-new--v1.png"
                      alt="انستجرام"
                      className="w-5 h-5"
                    />
                  </a>
                </div>
              </div>
              {/* شريط التنقل الرئيسي */}
              <nav className="bg-white shadow flex flex-col md:flex-row md:items-center md:justify-between px-4 py-3 border-b border-[#caaa95]">
                <div className="flex items-center gap-3">
                  <img
                    src="https://ext.same-assets.com/200402770/3736915175.png"
                    alt="شعار الديار"
                    className="w-14"
                  />
                  <span className="font-bold text-lg text-[#39383d]">
                    الديار العالمية
                  </span>
                </div>
                <ul className="flex-1 flex flex-wrap justify-center md:justify-start gap-4 mt-3 md:mt-0">
                  <li>
                    <a href="#" className="hover:text-[#b8975d] transition">
                      الرئيسية
                    </a>
                  </li>
                  <li>
                    <a href="#services" className="hover:text-[#b8975d] transition">
                      خدماتنا
                    </a>
                  </li>
                  <li>
                    <a href="#projects" className="hover:text-[#b8975d] transition">
                      الأعمال
                    </a>
                  </li>
                  <li>
                    <a href="#about" className="hover:text-[#b8975d] transition">
                      من نحن
                    </a>
                  </li>
                  <li>
                    <a href="#contact" className="hover:text-[#b8975d] transition">
                      اتصل بنا
                    </a>
                  </li>
                  <li>
                    {/* رابط صفحة المظلات */}
                    <Link to="/mazallat" className="hover:text-[#b8975d] transition">
                      مظلات
                    </Link>
                  </li>
                </ul>
                <div className="flex items-center gap-2 mt-3 md:mt-0">
                  <a
                    href="#contact"
                    className="px-3 py-1 rounded bg-[#b8975d] text-white font-semibold shadow hover:bg-[#39383d] transition whitespace-nowrap"
                  >
                    اطلب عرض
                  </a>
                  <a
                    href="tel:+966553719009"
                    className="px-3 py-1 rounded border border-[#b8975d] text-[#b8975d] font-semibold shadow hover:bg-[#b8975d] hover:text-white transition whitespace-nowrap"
                  >
                    اتصل الآن
                  </a>
                </div>
              </nav>
              {/* هيدر مع بانر تحفيزي أكبر وحركة */}
              <header className="relative w-full h-[380px] md:h-[460px] flex items-center justify-center overflow-hidden bg-[#a3a3a3] animate-fade-in">
                <img
                  src="https://ext.same-assets.com/200402770/3400896523.jpeg"
                  alt="مظلات الديار"
                  className="absolute inset-0 w-full h-full object-cover object-center opacity-80 scale-105 transition-transform duration-700 hover:scale-100"
                />
                <div className="relative z-10 p-8 flex flex-col items-center justify-center text-center bg-black bg-opacity-50 rounded-2xl animate-rise-fade-in">
                  <h1 className="text-4xl md:text-6xl font-extrabold text-[#f2c684] drop-shadow mb-2 animate-fade-in">
                    الديار العالمية للمظلات والسواتر
                  </h1>
                  <p className="mt-4 text-lg md:text-2xl text-white max-w-2xl drop-shadow animate-fade-in delay-100">
                    روّاد مظلات البر قمة التميز منذ 15 سنة. حلول عصرية وجودة مكفولة لكل مشروع.
                    لا تبدأ مشروعك قبل استشارة خبرائنا!
                  </p>
                  <div className="flex gap-4 mt-6 animate-rise-fade-in delay-200">
                    <a
                      href="#contact"
                      className="px-8 py-3 rounded-full bg-[#51ac41] text-white font-bold text-lg shadow hover:bg-[#b8975d] transition animate-pulse"
                    >
                      استشارة مجانية<br className="sm:hidden" /> الآن!
                    </a>
                    <a
                      href="#services"
                      className="px-8 py-3 rounded-full bg-[#b09257] text-white font-bold text-lg shadow hover:bg-[#8c5f44] transition"
                    >
                      اكتشف خدماتنا
                    </a>
                  </div>
                </div>
                {/* شريط لماذا تختار الديار العالمية (Banner) */}
                <section className="bg-gradient-to-l from-[#b09257] to-[#8c5f44] text-white py-4 shadow-md w-full absolute bottom-0 left-0">
                  <div className="max-w-7xl mx-auto px-4">
                    <h2 className="text-xl md:text-2xl font-bold text-center mb-3">
                      لماذا تختار الديار العالمية؟
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="flex items-center gap-3 animate-rise-fade-in">
                        <div className="bg-white rounded-full p-2 flex justify-center items-center">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="w-6 h-6 text-[#b09257]"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                            />
                          </svg>
                        </div>
                        <div>
                          <h3 className="font-semibold">ضمان جودة 10 سنوات</h3>
                          <p className="text-sm text-white/80">
                            ثقة عملائنا مضمونة بكفالة حقيقية
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 animate-rise-fade-in delay-100">
                        <div className="bg-white rounded-full p-2 flex justify-center items-center">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="w-6 h-6 text-[#b09257]"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M13 10V3L4 14h7v7l9-11h-7z"
                            />
                          </svg>
                        </div>
                        <div>
                          <h3 className="font-semibold">تنفيذ سريع ومتقن</h3>
                          <p className="text-sm text-white/80">
                            إنجاز المشاريع بوقت قياسي
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 animate-rise-fade-in delay-200">
                        <div className="bg-white rounded-full p-2 flex justify-center items-center">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="w-6 h-6 text-[#b09257]"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
                            />
                          </svg>
                        </div>
                        <div>
                          <h3 className="font-semibold">استشارات هندسية مجانية</h3>
                          <p className="text-sm text-white/80">
                            خبراؤنا بخدمتكم على مدار الأسبوع
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </section>
              </header>
              {/* كروت الإحصائيات */}
              <section className="my-8 max-w-7xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
                <div className="bg-white rounded shadow p-6 flex flex-col items-center animate-rise-fade-in">
                  <span className="text-3xl md:text-4xl font-bold text-[#b09257]">
                    500+
                  </span>
                  <span className="mt-2 text-sm md:text-base font-semibold text-[#302a23]">
                    مشروع منفذ
                  </span>
                </div>
                <div className="bg-white rounded shadow p-6 flex flex-col items-center animate-rise-fade-in delay-75">
                  <span className="text-3xl md:text-4xl font-bold text-[#b09257]">
                    15+
                  </span>
                  <span className="mt-2 text-sm md:text-base font-semibold text-[#302a23]">
                    سنوات خبرة
                  </span>
                </div>
                <div className="bg-white rounded shadow p-6 flex flex-col items-center animate-rise-fade-in delay-150">
                  <span className="text-3xl md:text-4xl font-bold text-[#b09257]">
                    10+
                  </span>
                  <span className="mt-2 text-sm md:text-base font-semibold text-[#302a23]">
                    جوائز جودة
                  </span>
                </div>
                <div className="bg-white rounded shadow p-6 flex flex-col items-center animate-rise-fade-in delay-200">
                  <span className="text-3xl md:text-4xl font-bold text-[#b09257]">
                    350+
                  </span>
                  <span className="mt-2 text-sm md:text-base font-semibold text-[#302a23]">
                    عميل راضي
                  </span>
                </div>
              </section>
              {/* دائرة مميزات الديار */}
              <section className="my-20 max-w-4xl mx-auto">
                <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center text-[#b8975d] animate-fade-in">
                  ما يميز الديار العالمية
                </h2>
                <div className="flex flex-col md:flex-row gap-6 justify-center items-center">
                  <div className="flex flex-wrap gap-5 justify-center items-center">
                    {/* مميزات حول الشعار */}
                    <div className="flex flex-col items-center gap-2 bg-white shadow rounded-full p-4 w-32 h-32 border border-[#caaa95] hover:bg-[#f9f9f8] transition animate-rise-fade-in">
                      <img
                        src="https://img.icons8.com/ios-filled/50/b8975d/verified-account.png"
                        alt="كفالة"
                        className="w-8 h-8"
                      />
                      <span className="mt-2 font-bold text-[#39383d]">
                        كفالة 10 سنوات
                      </span>
                    </div>
                    <div className="flex flex-col items-center gap-2 bg-white shadow rounded-full p-4 w-32 h-32 border border-[#caaa95] hover:bg-[#f9f9f8] transition animate-rise-fade-in delay-75">
                      <img
                        src="https://img.icons8.com/ios-filled/50/b8975d/star--v1.png"
                        alt="جودة الخامات"
                        className="w-8 h-8"
                      />
                      <span className="mt-2 font-bold text-[#39383d]">
                        جودة خامات ممتازة
                      </span>
                    </div>
                    <div className="flex flex-col items-center gap-2 bg-white shadow rounded-full p-4 w-32 h-32 border border-[#caaa95] hover:bg-[#f9f9f8] transition animate-rise-fade-in delay-150">
                      <img
                        src="https://img.icons8.com/ios-filled/50/b8975d/engineering.png"
                        alt="فريق هندسي"
                        className="w-8 h-8"
                      />
                      <span className="mt-2 font-bold text-[#39383d]">
                        فريق هندسي متمرس
                      </span>
                    </div>
                    <div className="flex flex-col items-center gap-2 bg-white shadow rounded-full p-4 w-32 h-32 border border-[#caaa95] hover:bg-[#f9f9f8] transition animate-rise-fade-in delay-200">
                      <img
                        src="https://img.icons8.com/ios-filled/50/b8975d/clock--v1.png"
                        alt="سرعة التنفيذ"
                        className="w-8 h-8"
                      />
                      <span className="mt-2 font-bold text-[#39383d]">
                        سرعة تنفيذ قياسية
                      </span>
                    </div>
                    <div className="flex flex-col items-center gap-2 bg-white shadow rounded-full p-4 w-32 h-32 border border-[#caaa95] hover:bg-[#f9f9f8] transition animate-rise-fade-in delay-300">
                      <img
                        src="https://img.icons8.com/ios-filled/50/b8975d/help.png"
                        alt="استشارة مجانية"
                        className="w-8 h-8"
                      />
                      <span className="mt-2 font-bold text-[#39383d]">
                        استشارة مجانية
                      </span>
                    </div>
                    <div className="flex flex-col items-center gap-2 bg-white shadow rounded-full p-4 w-32 h-32 border border-[#caaa95] hover:bg-[#f9f9f8] transition animate-rise-fade-in delay-400">
                      <img
                        src="https://img.icons8.com/ios-filled/50/b8975d/customer-support.png"
                        alt="دعم سريع"
                        className="w-8 h-8"
                      />
                      <span className="mt-2 font-bold text-[#39383d]">
                        دعم سريع بعد البيع
                      </span>
                    </div>
                  </div>
                  <div className="flex justify-center items-center mt-8 md:mt-0 md:ml-10 animate-rise-fade-in delay-200">
                    <img
                      src="https://ext.same-assets.com/200402770/3736915175.png"
                      alt="شعار الديار"
                      className="w-32 h-32 object-contain rounded-full shadow-lg border-2 border-[#b8975d] bg-white"
                    />
                  </div>
                </div>
              </section>
              {/* قسم FAQ (Accordion) */}
              <section className="my-16 max-w-3xl mx-auto animate-fade-in">
                <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center text-[#b8975d]">
                  الأسئلة الشائعة
                </h2>
                <div className="space-y-4">
                  <details className="bg-white border rounded shadow p-4 transition-all duration-300 hover:shadow-lg">
                    <summary className="font-bold text-[#39383d] cursor-pointer">
                      كم مدة الكفالة على المنتجات؟
                    </summary>
                    <p className="mt-2 text-[#8e634d]">
                      جميع مظلاتنا بكفالة 10 سنوات ضد عيوب الخامات والتصنيع.
                    </p>
                  </details>
                  <details className="bg-white border rounded shadow p-4 transition-all duration-300 hover:shadow-lg">
                    <summary className="font-bold text-[#39383d] cursor-pointer">
                      ما الوقت المتوقع للتنفيذ والتركيب؟
                    </summary>
                    <p className="mt-2 text-[#8e634د]">
                      ننتهي من التنفيذ والتركيب خلال أيام قليلة حسب حجم المشروع والمواسم.
                    </p>
                  </details>
                  <details className="bg-white border rounded shadow p-4 transition-all duration-300 hover:shadow-lg">
                    <summary className="font-bold text-[#39383d] cursor-pointer">
                      هل توفرون استشارات وزيارات مجانية؟
                    </summary>
                    <p className="mt-2 text-[#8e634d]">
                      نعم، الاستشارات وزيارة الموقع مجانية بالكامل قبل التعاقد.
                    </p>
                  </details>
                  <details className="bg-white border rounded shadow p-4 transition-all duration-300 hover:shadow-lg">
                    <summary className="font-bold text-[#39383d] cursor-pointer">
                      هل يمكن تنفيذ تصاميم مخصصة حسب الطلب؟
                    </summary>
                    <p className="mt-2 text-[#8e634d]">
                      نعم، نحن نتميز بقدرتنا على تنفيذ أي تصميم يختاره العميل بجودة عالية.
                    </p>
                  </details>
                </div>
              </section>
              {/* قسم الخدمات */}
              <section className="my-16 max-w-7xl mx-auto px-4" id="services">
                <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center animate-fade-in">
                  خدماتنا
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* كرت السواتر */}
                  <div className="bg-white rounded-xl shadow flex flex-col p-4 items-center animate-rise-fade-in">
                    <img
                      src="https://ext.same-assets.com/200402770/531069762.jpeg"
                      alt="السواتر"
                      className="h-32 w-full object-cover rounded mb-2"
                    />
                    <h3 className="font-semibold text-lg mt-1">السواتر</h3>
                    <p className="text-[#8c5f44] mt-2 text-center text-sm flex-1">
                      تصاميم متنوعة من السواتر بجودة عالية للحماية والخصوصية تناسب جميع
                      المباني.
                    </p>
                    <a
                      href="#"
                      className="mt-4 px-5 py-2 bg-[#b09257] text-white rounded-full font-semibold transition hover:bg-[#8c5f44]"
                    >
                      عرض التفاصيل
                    </a>
                  </div>
                  {/* كرت الخيام الملكية */}
                  <div className="bg-white rounded-xl shadow flex flex-col p-4 items-center animate-rise-fade-in delay-75">
                    <img
                      src="https://ext.same-assets.com/200402770/1914607147.jpeg"
                      alt="خيام ملكية"
                      className="h-32 w-full object-cover rounded mb-2"
                    />
                    <h3 className="font-semibold text-lg mt-1">خيام ملكية</h3>
                    <p className="text-[#8c5f44] mt-2 text-center text-sm flex-1">
                      خيام ملكية عصرية لجميع المناسبات بتصميم واحترافية وجودة عالية
                      مضمونة.
                    </p>
                    <a
                      href="#"
                      className="mt-4 px-5 py-2 bg-[#b09257] text-white rounded-full font-semibold transition hover:bg-[#8c5f44]"
                    >
                      عرض التفاصيل
                    </a>
                  </div>
                  {/* كرت المظلات */}
                  <div className="bg-white rounded-xl shadow flex flex-col p-4 items-center animate-rise-fade-in delay-150">
                    <img
                      src="https://ext.same-assets.com/200402770/3400896523.jpeg"
                      alt="المظلات"
                      className="h-32 w-full object-cover rounded mb-2"
                    />
                    <h3 className="font-semibold text-lg mt-1">المظلات</h3>
                    <p className="text-[#8c5f44] mt-2 text-center text-sm flex-1">
                      مظلات سيارات وحدائق ومدارس تنفيذ احترافي مقاوم للعوامل الجوية.
                    </p>
                    <Link
                      to="/mazallat"
                      className="mt-4 px-5 py-2 bg-[#b09257] text-white rounded-full font-semibold transition hover:bg-[#8c5f44]"
                    >
                      عرض التفاصيل
                    </Link>
                  </div>
                  {/* كرت البرجولات */}
                  <div className="bg-white rounded-xl shadow flex flex-col p-4 items-center animate-rise-fade-in delay-200">
                    <img
                      src="https://ext.same-assets.com/200402770/3318001237.jpeg"
                      alt="البرجولات"
                      className="h-32 w-full object-cover rounded mb-2"
                    />
                    <h3 className="font-semibold text-lg mt-1">البرجولات</h3>
                    <p className="text-[#8c5f44] mt-2 text-center text-sm flex-1">
                      برجولات عصرية للحدائق والاستراحات وتنفيذ متخصص لكافة الأذواق.
                    </p>
                    <a
                      href="#"
                      className="mt-4 px-5 py-2 bg-[#b09257] text-white rounded-full font-semibold transition hover:bg-[#8c5f44]"
                    >
                      عرض التفاصيل
                    </a>
                  </div>
                  {/* كرت بيوت الشعر */}
                  <div className="bg-white rounded-xl shadow flex flex-col p-4 items-center animate-rise-fade-in delay-300">
                    <img
                      src="https://ext.same-assets.com/200402770/60439396.jpeg"
                      alt="بيوت شعر"
                      className="h-32 w-full object-cover rounded mb-2"
                    />
                    <h3 className="font-semibold text-lg mt-1">بيوت شعر</h3>
                    <p className="text-[#8c5f44] mt-2 text-center text-sm flex-1">
                      بيوت شعر ملكية فاخرة مقاومة لعوامل الطقس والتفصيل على الطلب.
                    </p>
                    <a
                      href="#"
                      className="mt-4 px-5 py-2 bg-[#b09257] text-white rounded-full font-semibold transition hover:bg-[#8c5f44]"
                    >
                      عرض التفاصيل
                    </a>
                  </div>
                  {/* كرت تنسيق الحدائق */}
                  <div className="bg-white rounded-xl shadow flex flex-col p-4 items-center animate-rise-fade-in delay-400">
                    <img
                      src="https://ext.same-assets.com/200402770/3867427210.jpeg"
                      alt="تنسيق حدائق"
                      className="h-32 w-full object-cover rounded mb-2"
                    />
                    <h3 className="font-semibold text-lg mt-1">تنسيق حدائق</h3>
                    <p className="text-[#8c5f44] mt-2 text-center text-sm flex-1">
                      تنسيق وتصميم حدائق باحترافية شاملة شبكات الري وتصميم المسطحات.
                    </p>
                    <a
                      href="#"
                      className="mt-4 px-5 py-2 bg-[#b09257] text-white rounded-full font-semibold transition hover:bg-[#8c5f44]"
                    >
                      عرض التفاصيل
                    </a>
                  </div>
                </div>
              </section>
              {/* من نحن */}
              <section
                className="my-20 max-w-5xl mx-auto flex flex-col md:flex-row items-center gap-8 bg-white rounded-xl shadow p-8 animate-fade-in"
                id="about"
              >
                <div className="flex-1 flex flex-col justify-center items-start">
                  <h2 className="text-2xl md:text-3xl font-bold mb-4 text-[#b09257]">
                    من نحن
                  </h2>
                  <p className="mb-6 text-[#302a23] leading-loose text-lg">
                    مؤسسة الديار العالمية تقدم خبرة أكثر من 15 عامًا في تصميم وتنفيذ
                    المظلات والسواتر والخيام الملكية والبرجولات وبيوت الشعر وتنـسيق
                    الحدائق. معتمدون على الجودة والالتزام التام بأعلى معايير البناء
                    وتقديم أفضل الحلول للعملاء في جدة والمملكة.
                  </p>
                  <a
                    href="#contact"
                    className="px-6 py-2 bg-[#b09257] text-white rounded-full font-semibold hover:bg-[#8c5f44] transition"
                  >
                    تواصل معنا
                  </a>
                </div>
                <div className="flex-1 flex justify-center">
                  <img
                    src="https://ext.same-assets.com/200402770/574858840.png"
                    alt="شعار مؤسسة الديار العالمية"
                    className="w-52 h-52 object-contain"
                    style={{ maxWidth: "210px", maxHeight: "210px" }}
                  />
                </div>
              </section>
              {/* فريق العمل */}
              <section className="my-20 max-w-5xl mx-auto flex flex-col md:flex-row-reverse items-center gap-8 bg-[#fafafa] border border-[#c3ad90] rounded-xl shadow p-8 animate-fade-in">
                <div className="flex-1 flex flex-col justify-center items-start">
                  <h2 className="text-2xl md:text-3xl font-bold mb-4 text-[#b09257]">
                    فريق هندسي متميز في خدمتك
                  </h2>
                  <ul className="mb-6 text-[#302a23] space-y-2 text-lg list-disc list-inside">
                    <li>مهندسون وفنيون بخبرة عالية في التنفيذ والإشراف</li>
                    <li>التزام بجودة العمل والدقة والابتكار</li>
                    <li>خدمة عملاء سريعة واستشارات مجانية</li>
                  </ul>
                </div>
                <div className="flex-1 flex justify-center">
                  <img
                    src="https://ext.same-assets.com/200402770/3782621980.jpeg"
                    alt="فريق مؤسسة الديار العالمية"
                    className="w-64 h-44 object-cover rounded-lg shadow"
                  />
                </div>
              </section>
              {/* بعض الأعمال */}
              <section
                className="my-20 max-w-7xl mx-auto px-4 animate-fade-in"
                id="projects"
              >
                <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center text-[#b09257]">
                  بعض أعمالنا
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                  <div className="bg-white rounded-lg shadow flex flex-col animate-rise-fade-in">
                    <img
                      src="https://ext.same-assets.com/200402770/3221027249.jpeg"
                      alt="مشروع 1"
                      className="h-40 w-full object-cover rounded-t"
                    />
                    <div className="p-3 flex-1 flex flex-col">
                      <span className="font-semibold text-lg mb-1">مظلات سيارات</span>
                      <span className="text-[#8c5f44] text-sm">
                        تنفيذ مظلات سيارات عصرية بجدة
                      </span>
                    </div>
                  </div>
                  <div className="bg-white rounded-lg shadow flex flex-col animate-rise-fade-in delay-75">
                    <img
                      src="https://ext.same-assets.com/200402770/3377810294.jpeg"
                      alt="مشروع 2"
                      className="h-40 w-full object-cover rounded-t"
                    />
                    <div className="p-3 flex-1 flex flex-col">
                      <span className="font-semibold text-lg mb-1">خيام ملكية</span>
                      <span className="text-[#8c5f44] text-sm">
                        مجالس وخيام فاخرة للمناسبات
                      </span>
                    </div>
                  </div>
                  <div className="bg-white rounded-lg shadow flex flex-col animate-rise-fade-in delay-150">
                    <img
                      src="https://ext.same-assets.com/200402770/3574464506.jpeg"
                      alt="مشروع 3"
                      className="h-40 w-full object-cover rounded-t"
                    />
                    <div className="p-3 flex-1 flex flex-col">
                      <span className="font-semibold text-lg mb-1">
                        برجولات حدائق
                      </span>
                      <span className="text-[#8c5f44] text-sm">
                        برجولات عملية بتصاميم عصرية
                      </span>
                    </div>
                  </div>
                  <div className="bg-white rounded-lg shadow flex flex-col animate-rise-fade-in delay-200">
                    <img
                      src="https://ext.same-assets.com/200402770/2876684063.jpeg"
                      alt="مشروع 4"
                      className="h-40 w-full object-cover rounded-t"
                    />
                    <div className="p-3 flex-1 flex flex-col">
                      <span className="font-semibold text-lg mb-1">
                        سواتر حديد وخشب
                      </span>
                      <span className="text-[#8c5f44] text-sm">
                        سواتر لمختلف المباني حماية وخصوصية
                      </span>
                    </div>
                  </div>
                  <div className="bg-white rounded-lg shadow flex flex-col animate-rise-fade-in delay-300">
                    <img
                      src="https://ext.same-assets.com/200402770/1219449442.jpeg"
                      alt="مشروع 5"
                      className="h-40 w-full object-cover rounded-t"
                    />
                    <div className="p-3 flex-1 flex flex-col">
                      <span className="font-semibold text-lg mb-1">تنسيق حدائق</span>
                      <span className="text-[#8c5f44] text-sm">
                        تصميم وتنسيق الحدائق المنزلية الحديثة
                      </span>
                    </div>
                  </div>
                  <div className="bg-white rounded-lg shadow flex flex-col animate-rise-fade-in delay-400">
                    <img
                      src="https://ext.same-assets.com/200402770/1218359497.jpeg"
                      alt="مشروع 6"
                      className="h-40 w-full object-cover rounded-t"
                    />
                    <div className="p-3 flex-1 flex flex-col">
                      <span className="font-semibold text-lg mb-1">
                        بيوت شعر فاخرة
                      </span>
                      <span className="text-[#8c5f44] text-sm">
                        تفصيل بيوت شعر للمخيمات والاستراحات
                      </span>
                    </div>
                  </div>
                </div>
              </section>
              {/* شهادات العملاء (Testimonials) */}
              <section className="my-12 max-w-3xl mx-auto">
                <h2 className="text-xl md:text-2xl font-bold mb-8 text-center text-[#b8975d] animate-fade-in">
                  ماذا يقول عملاؤنا؟
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-white border border-[#c3ad90] rounded-lg shadow p-6 flex flex-col items-center animate-fade-in delay-75">
                    <img src="https://randomuser.me/api/portraits/men/32.jpg" alt="عميل الديار" className="w-20 h-20 rounded-full mb-2 border-2 border-[#b09257] shadow" />
                    <blockquote className="italic text-center text-[#302a23]">
                      “أشكر فريق الديار على الاحترافية في التنفيذ وسرعة الإنجاز. أنصح الجميع بالتعامل معهم.”
                    </blockquote>
                    <span className="mt-3 font-bold text-[#8c5f44]">عبدالله القحطاني - جدة</span>
                  </div>
                  <div className="bg-white border border-[#c3ad90] rounded-lg shadow p-6 flex flex-col items-center animate-fade-in delay-150">
                    <img src="https://randomuser.me/api/portraits/women/68.jpg" alt="عميلة الديار" className="w-20 h-20 rounded-full mb-2 border-2 border-[#b09257] shadow" />
                    <blockquote className="italic text-center text-[#302a23]">
                      “خدمة رائعة وشغل متقن جدًا والتسليم كان أسرع من المتوقع. بالتأكيد سأتعامل معهم مجددًا.”
                    </blockquote>
                    <span className="mt-3 font-bold text-[#8c5f44]">أ. مها السلمي - مكة</span>
                  </div>
                </div>
              </section>
              {/* جدول مقارنة الديار مع المنافسين */}
              <section className="my-10 max-w-3xl mx-auto animate-fade-in">
                <h2 className="text-xl font-bold mb-3 text-center text-[#b09257]">
                  مقارنة سريعة بين الديار والمنافسين
                </h2>
                <div className="overflow-x-auto">
                  <table className="w-full text-center rounded-xl overflow-hidden border border-[#c3ad90] bg-white text-sm shadow animate-fade-in delay-75">
                    <thead className="bg-[#d2c3a7] text-[#302a23]">
                      <tr>
                        <th className="font-bold py-2 px-2">الميزة</th>
                        <th className="font-bold py-2 px-2">الديار</th>
                        <th className="font-bold py-2 px-2">شركة عادية</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td className="py-2 px-2">مدة الكفالة</td>
                        <td className="py-2 px-2 text-[#51ac41] font-semibold">10 سنوات</td>
                        <td className="py-2 px-2 text-[#b09257]">سنة فقط أو أقل</td>
                      </tr>
                      <tr className="bg-[#fafafa]">
                        <td className="py-2 px-2">سرعة التنفيذ</td>
                        <td className="py-2 px-2 text-[#51ac41] font-semibold">خلال أيام</td>
                        <td className="py-2 px-2 text-[#b09257]">قد تصل لأسابيع</td>
                      </tr>
                      <tr>
                        <td className="py-2 px-2">جودة الخامات</td>
                        <td className="py-2 px-2 text-[#51ac41] font-semibold">صناعة محلية ممتازة</td>
                        <td className="py-2 px-2 text-[#b09257]">أحيانًا مستورد غير مضمون</td>
                      </tr>
                      <tr className="bg-[#fafafa]">
                        <td className="py-2 px-2">خدمة ما بعد البيع</td>
                        <td className="py-2 px-2 text-[#51ac41] font-semibold">دعم واستشارة 24/7</td>
                        <td className="py-2 px-2 text-[#b09257]">نادراً ومحدود الدعم</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </section>
              {/* تواصل معنا */}
              <section
                className="my-20 max-w-5xl mx-auto bg-white p-8 rounded-xl shadow border border-[#d2c3a7] animate-fade-in"
                id="contact"
              >
                <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center text-[#b09257]">
                  تواصل معنا
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <form className="flex flex-col gap-4">
                    <input
                      type="text"
                      placeholder="الاسم الكامل"
                      className="border rounded p-3 outline-none focus:border-[#b09257]"
                    />
                    <input
                      type="tel"
                      placeholder="رقم الجوال"
                      className="border rounded p-3 outline-none focus:border-[#b09257]"
                    />
                    <input
                      type="email"
                      placeholder="البريد الإلكتروني"
                      className="border rounded p-3 outline-none focus:border-[#b09257]"
                    />
                    <textarea
                      rows={4}
                      placeholder="اكتب رسالتك هنا..."
                      className="border rounded p-3 outline-none focus:border-[#b09257] resize-none"
                    />
                    <button
                      type="submit"
                      className="bg-[#b09257] hover:bg-[#8c5f44] transition text-white font-bold py-2 rounded-full"
                    >
                      إرسال
                    </button>
                  </form>
                  <div className="flex flex-col gap-6 justify-center items-start">
                    <div>
                      <span className="block font-semibold text-[#8c5f44]">
                        الهاتف:
                      </span>
                      <a
                        href="tel:+966553719009"
                        className="text-lg font-medium text-[#302a23]"
                      >
                        0553719009
                      </a>
                    </div>
                    <div>
                      <span className="block font-semibold text-[#8c5f44]">
                        البريد الالكتروني:
                      </span>
                      <a
                        href="mailto:fidralfidral@gmail.com"
                        className="text-lg font-medium text-[#302a23]"
                      >
                        fidralfidral@gmail.com
                      </a>
                    </div>
                    <div>
                      <span className="block font-semibold text-[#8c5f44]">
                        العنوان:
                      </span>
                      <span className="text-lg font-medium text-[#302a23]">
                        جدة – المملكة العربية السعودية
                      </span>
                    </div>
                    <div className="flex gap-4 mt-3">
                      <a
                        href="https://wa.me/+966553719009"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <img
                          src="https://img.icons8.com/color/48/000000/whatsapp--v1.png"
                          alt="واتساب"
                          className="w-8 h-8"
                        />
                      </a>
                      <a
                        href="https://www.instagram.com/aldiyarglobal/"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <img
                          src="https://img.icons8.com/color/48/000000/instagram-new--v1.png"
                          alt="انستجرام"
                          className="w-8 h-8"
                        />
                      </a>
                    </div>
                  </div>
                </div>
              </section>
              <main className="max-w-7xl mx-auto px-4 py-8 space-y-10">
                {/* هنا ستضاف: خدماتنا، من نحن، فريق العمل، بعض الأعمال، تواصل معنا */}
              </main>
              {/* الفوتر */}
              <footer className="bg-[#302a23] text-[#fafafa] py-8 mt-14">
                <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row md:justify-between md:items-start gap-10">
                  <div className="flex-1 mb-6">
                    <img
                      src="https://ext.same-assets.com/200402770/3736915175.png"
                      alt="شعار الديار"
                      className="w-28 mb-2"
                    />
                    <p className="text-[#c3ad90] text-sm pb-3">
                      مؤسسة الديار العالمية للمظلات والسواتر والبرجولات والديكورات
                      الداخلية والخارجية بجدة وكافة أنحاء المملكة
                    </p>
                  </div>
                  <div className="flex-1 mb-6">
                    <h3 className="text-[#b09257] font-semibold mb-3">روابط سريعة</h3>
                    <ul className="space-y-2 text-sm">
                      <li>
                        <a href="#" className="hover:underline">
                          الرئيسية
                        </a>
                      </li>
                      <li>
                        <a href="#services" className="hover:underline">
                          خدماتنا
                        </a>
                      </li>
                      <li>
                        <a href="#projects" className="hover:underline">
                          بعض الأعمال
                        </a>
                      </li>
                      <li>
                        <a href="#contact" className="hover:underline">
                          تواصل معنا
                        </a>
                      </li>
                      <li>
                        <Link to="/mazallat" className="hover:underline">
                          مظلات
                        </Link>
                      </li>
                    </ul>
                  </div>
                  <div className="flex-1 mb-6">
                    <h3 className="text-[#b09257] font-semibold mb-3">
                      معلومات التواصل
                    </h3>
                    <ul className="space-y-2 text-sm">
                      <li>
                        الهاتف:{" "}
                        <a
                          href="tel:+966553719009"
                          className="text-[#fafafa] font-bold hover:underline"
                        >
                          0553719009
                        </a>
                      </li>
                      <li>
                        البريد:{" "}
                        <a
                          href="mailto:fidralfidral@gmail.com"
                          className="text-[#fafafa] hover:underline"
                        >
                          fidralfidral@gmail.com
                        </a>
                      </li>
                      <li>العنوان: جدة – المملكة العربية السعودية</li>
                    </ul>
                    <div className="flex gap-3 mt-3">
                      <a
                        href="https://wa.me/+966553719009"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <img
                          src="https://img.icons8.com/color/48/000000/whatsapp--v1.png"
                          alt="واتساب"
                          className="w-7 h-7"
                        />
                      </a>
                      <a
                        href="https://www.instagram.com/aldiyarglobal/"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <img
                          src="https://img.icons8.com/color/48/000000/instagram-new--v1.png"
                          alt="انستجرام"
                          className="w-7 h-7"
                        />
                      </a>
                    </div>
                  </div>
                </div>
                <div className="border-t border-[#b09257] mt-8 pt-4 text-center text-[#c3ad90] text-xs">
                  جميع الحقوق محفوظة © 2024 مؤسسة الديار العالمية
                </div>
              </footer>
            </div>
          }
        />
      </Routes>
    </Router>
  );
}
